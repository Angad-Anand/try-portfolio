import React from "react";
import "./Mode.scss";

function Mode() {
  return <div>Mode</div>;
}

export default Mode;
