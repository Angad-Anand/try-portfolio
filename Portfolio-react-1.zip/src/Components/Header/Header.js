import React, { useEffect } from "react";
import "./Header.scss";
import "splitting/dist/splitting.css";
import "splitting/dist/splitting-cells.css";
import Splitting from "splitting";
// import {logo} from "../assets/download-solid.svg";

function Header() {
  useEffect(() => {
    Splitting(); // Initialize Splitting.js after component mounts
  }, []);
  return (
    <header className="header">
      <nav className="nav">
        <a href="home" className="nav_left">
          Angad
          <br />
          Anand
        </a>
        <div className="nav_right">
          <ul className="nav-list">
            <li className="nav-item shift-right" data-splitting>
              <a href="home">HOME</a>
            </li>
            <li className="nav-item shift-right" data-splitting>
              <a href="about">ABOUT</a>
            </li>
            <li className="nav-item shift-right" data-splitting>
              <a href="resume">RESUME</a>
            </li>
            <li className="nav-item shift-right" data-splitting>
              <a href="portfolio">PORTFOLIO</a>
            </li>
            <li className="nav-item shift-right" data-splitting>
              <a href="contacts">CONTACTS</a>
            </li>
            <li className="nav-item shift-right" data-splitting>
              <a href="blog">BLOG</a>
            </li>
            <li className="nav-item shift-right" data-splitting>
              <a href="mode">LIGHT MODE</a>
            </li>
            <div className="Down">
              <button className="nav-item flip-3d cv" data-splitting>
                <a
                  href="https://drive.google.com/file/d/1X2fvYbQXV0IfARjo05kPnCV8SIrHryYT/view?usp=sharing"
                  target="_blank"
                >
                  DOWNLOAD CV{" "}
                </a>
              </button>
            </div>
          </ul>
        </div>
      </nav>
    </header>
  );
}

export default Header;
